// import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1> Hello Dojo </h1>
      <h4> Things I need to do: </h4>
      <ul className="list">
        <li>Finish this bootcamp</li>
        <li>Get a job</li>
        <li>Find a home</li>
      </ul>
    </div>
  );
}

export default App;
